'use strict';
// Don't add or change anything above this comment.

/*
* Don't change the declaration of this function.
*/
function deepEqual(val1, val2) {

}

// Don't add or change anything below this comment.
module.exports = deepEqual;